import json
import boto3
from boto3.dynamodb.conditions import Attr


rekognition = boto3.client('rekognition', region_name='us-east-1')
dynamoDbEmployeeTableName = 'csci5409-employee'
dynamoDb = boto3.resource('dynamodb', region_name='us-east-1')
employeeTable = dynamoDb.Table(dynamoDbEmployeeTableName)

def lambda_handler(event, context):
    body = json.loads(event['body'])
    name = body.get('fileName').split('.')[0]
    first_name = name.split('_')[0]
    last_name = name.split('_')[1]
    
    
    response = employeeTable.scan( FilterExpression=Attr('firstName').eq(first_name) & Attr('lastName').eq(last_name) )
    
    items = response['Items'][0]
    
    employeeTable.delete_item(Key={"employeeId": items["employeeId"]})
    
    faces = [items["employeeId"]]
    rekognition.delete_faces(
        CollectionId='employees',
        FaceIds=faces
    )
    
    return {
        'statusCode': 200,
        'body': json.dumps('Hello from Lambda!')
    }
