import json
import boto3
from datetime import datetime

def lambda_handler(event, context):
    # TODO implement
    
    name = event['body']
    name = json.loads(name)
    first_name = name.get("firstName")
    last_name = name.get("lastName")
    
    now = datetime.now()
    
    date = now.strftime("%d/%m/%Y")
    time = now.strftime("%H:%M:%S")

    # Construct the message
    if first_name and last_name:
        message = f"Hello,\n{first_name} {last_name} has entered the office on {date} at {time}. Attendance Marked.\nThank You\nAttendance Bot"
    else:
        message = "Error: Unable to extract first name and last name from input data."
        
    # message = "Hello, \n " + name["firstName"] + " " + name["lastName"] + " has entered the office. Attendance Marked. \n Thank You \n Attendance Bot"
    sns = boto3.client('sns')
    sns.publish(
        TopicArn = 'arn:aws:sns:us-east-1:471112832723:email-notification',
        Message=message,
    )
    return buildResponse(200, None)

def buildResponse(statusCode, body=None):
    response = {
        'statusCode': statusCode,
        'headers': {
            "Access-Control-Allow-Headers" : "Content-Type",
              "Access-Control-Allow-Origin": "*",
            'Content-Type': 'application/json',
             "Access-Control-Allow-Methods": "OPTIONS,POST,GET,PATCH"
        }
    }
    if body is not None:
        response['body'] = json.dumps(body)
    return response