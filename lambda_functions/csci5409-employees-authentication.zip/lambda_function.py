import json
import boto3

s3 = boto3.client('s3')

rekognition = boto3.client('rekognition', region_name='us-east-1')

dynamoDbEmployeeTableName = 'csci5409-employee'
dynamoDb = boto3.resource('dynamodb', region_name='us-east-1')
employeeTable = dynamoDb.Table(dynamoDbEmployeeTableName)
bucketName = 'csci5409-visitors-images-database'
def lambda_handler(event, context):
    objectKey = event['queryStringParameters']['objectKey']
    image_bytes = s3.get_object(Bucket=bucketName, Key=objectKey)['Body'].read()
    response = rekognition.search_faces_by_image(
        CollectionId='employees',
        Image={'S3Object':{'Bucket':bucketName,'Name':objectKey}}
        # Image={'Bytes':image_bytes}
    )
    print( "response", response)

    for match in response['FaceMatches']:
        print(match['Face']['FaceId'], match['Face']['Confidence'])

        face = employeeTable.get_item(
            Key={
                'employeeId': match['Face']['FaceId']
            }
        )

        if 'Item' in face:
            print('Person Found:', face['Item'])
            return buildResponse(200, {
                'Message': 'Success',
                'firstName': face['Item']['firstName'],
                'lastName': face['Item']['lastName']
            })
    
    print('Person Not found in database')
    return buildResponse(403, {'Message': 'Person Not Found'})

def buildResponse(statusCode, body=None):
    response = {
        'statusCode': statusCode,
        'headers': {
            "Access-Control-Allow-Headers" : "Content-Type",
              "Access-Control-Allow-Origin": "*",
            'Content-Type': 'application/json',
             "Access-Control-Allow-Methods": "OPTIONS,POST,GET,PATCH"
        }
    }
    if body is not None:
        response['body'] = json.dumps(body)
    return response